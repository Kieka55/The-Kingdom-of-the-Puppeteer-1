﻿using UnityEngine;

namespace Zenject.Tests.Bindings.FromPrefab
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
